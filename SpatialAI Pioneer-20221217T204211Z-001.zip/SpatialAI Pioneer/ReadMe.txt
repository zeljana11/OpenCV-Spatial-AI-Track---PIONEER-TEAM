

Python version == 3.8
Required packages are listed in reqirements.txt

Run the script:

python tree_detection_depth.py

python tree_detection_depth.py -m yolo_v5_openvino_2021.4_6shave.blob -c yolo_v5.json
